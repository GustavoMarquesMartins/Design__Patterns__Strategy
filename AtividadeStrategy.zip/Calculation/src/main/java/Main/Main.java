package Main;

import Strategy.Calculation;
import Strategy.TypeCalculation;
import java.util.Scanner;
import java.util.concurrent.BrokenBarrierException;
import javax.swing.JOptionPane;

public class Main {

    public static void main(String args[]) {

        try (Scanner leitor = new Scanner(System.in)) {
            System.out.println(" QUAL TIPO DE CONTA VC DESEJA FAZER ? (1) SOMA (2) SUBTRACAO (3) MULTIPLICACAO (4) DIVISAO ");
            int escolha = leitor.nextInt();
            System.out.println(" INSIRA SEU PRIMEIRO NUMERO ");
            int num1 = leitor.nextInt();
            System.out.println(" INSIRA SEU SEGUNDO NUMERO ");
            int num2 = leitor.nextInt();
            TypeCalculation choise = TypeCalculation.values()[escolha - 1];
            Calculation cal = choise.AccountType();
            double resultado = cal.calculation(num1, num2);
            System.out.println(" Resultado = " + resultado);
        } catch (Exception erro) {
            System.err.println(" OS VALORES INSERIDOS NAO CORRESPONDEM AOS VALORES ACEITOS ");
        }
    }
}
