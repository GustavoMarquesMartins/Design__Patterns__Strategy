package Strategy;

public class Sum implements Calculation {

    @Override
    public double calculation(int number1, int number2) {
        return number1 + number2;
    }

}
