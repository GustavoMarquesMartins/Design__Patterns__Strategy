package Strategy;

public interface  Calculation {

    public double calculation(int number1,int number2);

}
