package Strategy;

public enum TypeCalculation {
    SUM {
        @Override
        public Calculation AccountType() {
            return new Sum();
        }
    },
    SUBTRACTION {
        @Override
        public Calculation AccountType() {
            return new Subtraction();
        }
    },
    MULTIPLICATION {
        @Override
        public Calculation AccountType() {
            return new Multiplication();
        }
    },
    DIVISION {
        @Override
        public Calculation AccountType() {
            return new Division();
        }
    };

    public abstract Calculation AccountType();

}
